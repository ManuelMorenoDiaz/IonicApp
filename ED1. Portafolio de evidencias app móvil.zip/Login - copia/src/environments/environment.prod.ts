export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyBlBLPhSlNAVxm8uJHBgXMrvqoKU6Bi_b8",
    authDomain: "finanzas-3d4ac.firebaseapp.com",
    projectId: "finanzas-3d4ac",
    storageBucket: "finanzas-3d4ac.appspot.com",
    messagingSenderId: "224305171749",
    appId: "1:224305171749:web:e70f04263517403dc59ecc",
    measurementId: "G-VF93LD7MZ5"
  }
};
